# لوحة الصف – مشروع أندرويد
## الطريقة 1: Android Studio
افتح المجلد في Android Studio ← انتظر المزامنة ← Build ▸ Build APK(s). الملف يظهر في app/build/outputs/apk/debug/
## الطريقة 2: بدون تثبيت أي برنامج (GitHub)
1. أنشئ مستودعاً جديداً على github.com وارفع كل محتويات هذا المجلد (بما فيها .github).
2. تبويب Actions ← Build APK ← انتظر دقيقتين ← حمّل app-debug.apk من Artifacts.
3. انقل الملف للجوال وثبّته (فعّل «تثبيت من مصادر غير معروفة»).
